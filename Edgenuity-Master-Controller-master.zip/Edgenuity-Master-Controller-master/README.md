# Edgenuity-Master-Controller
A user script to make Edgenuity more bearable.  

Most of the credit goes to https://greasyfork.org/en/scripts/395567-edgenuity-master-controller-v0-3/code, I just uploaded it to github.

If you want to contribute, just make a pull request.

## Installation

Install Link : https://greasyfork.org/en/scripts/406109-edgenuity-master-controller-v0-4/code

Go to https://greasyfork.org if you're new to userscripts

## Manual Installation

Required since greasyfork took the extension down.

First, install Tampermonkey or another similar userscript extension.  Next, click on it in the extension list.  On Chrome you may need to press the puzzle piece first, and on Firefox you may need to press the double arrows.  Select Tampermonkey or your prefered extension, then choose Create new script.  Now clear everything out of the file that pops up, and paste in the contents of the Edgenuity_Master_Controllerv0.4.user.js file.  Now hit file>save, or press CTRL+S.  Make sure the script is enabled, and refresh edgenuity if it's already open.

`VIVA LA RESISTANCE`
